# module-settings-scope-override

Changes settings from "world" to "client" scope

*Better rolls 5e: enabled
*Token Bar: roller